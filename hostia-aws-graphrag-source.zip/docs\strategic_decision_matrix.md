# Matriz De Decisi�n Estrat�gica

## 1. Migraci�n Temprana / Quick Wins

- Valor de Negocio: MEDIO/ALTO
- Complejidad/Dependencias: BAJA
- Deuda T�cnica: BAJA/MEDIA
- Consumo Mainframe: MEDIO/ALTO
- Riesgo Seguridad: BAJO

Decisi�n:
Replatforming o Rehosting.

## 2. Refactorizaci�n Estrat�gica

- Valor de Negocio: ALTO
- Complejidad/Dependencias: MEDIA/ALTA
- Deuda T�cnica: ALTA
- Consumo Mainframe: ALTO
- Riesgo Seguridad: MEDIO/ALTO

Decisi�n:
Rearchitecting / Cloud-Native.

## 3. Reemplazo

- Valor de Negocio: MEDIO/ALTO
- Complejidad/Dependencias: BAJA/MEDIA
- Deuda T�cnica: MUY ALTA
- Consumo Mainframe: MEDIO/ALTO
- Riesgo Seguridad: BAJO/MEDIO

Decisi�n:
Repurchasing / SaaS / Low-Code.

## 4. Encapsulamiento y Convivencia

- Valor de Negocio: ALTO
- Complejidad/Dependencias: MUY ALTA
- Deuda T�cnica: ALTA
- Consumo Mainframe: ALTO
- Riesgo Seguridad: ALTO

Decisi�n:
Retain / API-First.